/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador.excepcion;

/**
 *
 * @author hp
 */
public class FactsException extends Exception {
    
    //Aqui creamos las excepciones para poder lanzarlas.
    public FactsException(String message) {
        super(message);
    }  
}
