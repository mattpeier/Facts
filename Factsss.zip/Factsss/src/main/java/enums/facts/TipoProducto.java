package enums.facts;

///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package FACTS.Enums;
//
///**
// *
// * @author hp
// */
//public enum tipoProducto {
//    CAMISETASIMPLE, BOSSADETELA, FUNDAMÓVIL, FUNDADETABLET;
//
//    private static tipoProducto validar(String nombre) {
//
//        switch (nombre.toUpperCase()) {
//            case "CAMISETASIMPLE":
//                return CAMISETASIMPLE;
//            case "BOSSADETELA":
//                return BOSSADETELA;
//            case "FUNDAMÓVIL":
//                return FUNDAMÓVIL;
//            case "FUNDADETABLET":
//                return FUNDADETABLET;
//            default:
//                throw new IllegalArgumentException("Producto no válido: " + nombre);
//
//        }
//    }
//}
////Tenim els enums per poder revisar el numero de productes que hi ha
