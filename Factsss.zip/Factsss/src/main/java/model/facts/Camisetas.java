/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model.facts;

import model.facts.Producte;

/**
 *
 * @author hp
 */
public class Camisetas extends Producte {
    
    public Camisetas(int codigo, String producto, double precio, String tematica) {
        super(codigo, producto, tematica, precio);
    }
    
}
